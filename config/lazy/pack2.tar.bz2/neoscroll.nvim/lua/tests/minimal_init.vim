set rtp^=../..
set rtp^=.
