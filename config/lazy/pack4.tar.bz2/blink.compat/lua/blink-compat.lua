return require('blink.compat')
