# blink-ripgrep.nvim

<a href="https://dotfyle.com/plugins/mikavilpas/blink-ripgrep.nvim">
  <img
    src="https://dotfyle.com/plugins/mikavilpas/blink-ripgrep.nvim/shield?style=flat-square"
    alt="shield image for plugin usage"
  />
</a>

Ripgrep / git grep source for the
[blink.cmp](https://github.com/Saghen/blink.cmp) completion plugin. Adding it to
your configuration offers matching words from your entire project as
completions. This can reduce the chance of typos as well as repetitive typing.

It offers two search backends:

- **ripgrep** (`rg`): works out of the box for any project or directory
- **git grep**: is faster than `rg`, and works only for projects that are
  tracked by git
  - only searches files that are tracked by git
  - recommended: enable by setting `backend.use = "gitgrep-or-ripgrep"` (see
    below)

> [!NOTE]
>
> By default, a project root is considered to be the nearest ancestor directory
> containing a `.git` directory. This can be configured with the
> `project_root_marker` option.

![blink-ripgrep search with a context preview](./demo/screenshot.png)

Forked here (mikavilpas/blink.cmp) for my own use from
[niuiic/blink-cmp-rg.nvim](https://github.com/niuiic/blink-cmp-rg.nvim).

## 📦 Installation

The configuration of blink-ripgrep needs to be embedded into the configuration
for blink.

### Minimal config

You can use this config to quickly get started with the defaults.

Example for [lazy.nvim](https://lazy.folke.io/):

```lua
-- NOTE: you can leave out the type annotations if you don't want to use them

---@module "lazy"
---@type LazySpec
return {
  "saghen/blink.cmp",
  dependencies = {
    {
      "mikavilpas/blink-ripgrep.nvim",
      version = "*", -- use the latest stable version
    }
    -- 👆🏻👆🏻 add the dependency here
  },
  ---@module 'blink.cmp'
  ---@type blink.cmp.Config
  opts = {
    sources = {
      default = {
        "buffer",
        "ripgrep", -- 👈🏻 add "ripgrep" here
      },
      providers = {
        -- 👇🏻👇🏻 add the ripgrep provider config below
        ripgrep = {
          module = "blink-ripgrep",
          name = "Ripgrep",
          -- see the full configuration below for all available options
          ---@module "blink-ripgrep"
          ---@type blink-ripgrep.Options
          opts = {},
        },
      },
    },
  },
}
```

### Full config

<details>
<summary>Click to expand the full config</summary>

Example for [lazy.nvim](https://lazy.folke.io/):

```lua
-- NOTE: you can leave out the type annotations if you don't want to use them

---@module "lazy"
---@type LazySpec
return {
  "saghen/blink.cmp",
  dependencies = {
    {
      "mikavilpas/blink-ripgrep.nvim",
      version = "*", -- use the latest stable version
    },
    -- 👆🏻👆🏻 add the dependency here

    -- optional dependency used for toggling features on/off
    -- https://github.com/folke/snacks.nvim
    "folke/snacks.nvim",
  },
  ---@module 'blink.cmp'
  ---@type blink.cmp.Config
  opts = {
    sources = {
      default = {
        "buffer",
        "ripgrep", -- 👈🏻 add "ripgrep" here
      },
      providers = {
        -- 👇🏻👇🏻 add the ripgrep provider config below
        ripgrep = {
          module = "blink-ripgrep",
          name = "Ripgrep",
          -- the options below are optional, some default values are shown
          ---@module "blink-ripgrep"
          ---@type blink-ripgrep.Options
          opts = {
            -- the minimum length of the current word to start searching
            -- (if the word is shorter than this, the search will not start)
            prefix_min_len = 3,

            -- Specifies how to find the root of the project where the ripgrep
            -- search will start from. Accepts the same options as the marker
            -- given to `:h vim.fs.root()` which offers many possibilities for
            -- configuration. If none can be found, defaults to Neovim's cwd.
            --
            -- Examples:
            -- - ".git" (default)
            -- - { ".git", "package.json", ".root" }
            project_root_marker = ".git",

            -- When a result is found for a file whose filetype does not have a
            -- treesitter parser installed, fall back to regex based highlighting
            -- that is bundled in Neovim.
            fallback_to_regex_highlighting = true,

            -- Keymaps to toggle features on/off. This can be used to alter
            -- the behavior of the plugin without restarting Neovim. Nothing
            -- is enabled by default. Requires folke/snacks.nvim.
            toggles = {
              -- The keymap to toggle the plugin on and off from blink
              -- completion results. Example: "<leader>tg" ("toggle grep")
              on_off = nil,

              -- The keymap to toggle debug mode on/off. Example: "<leader>td" ("toggle debug")
              debug = nil,
            },

            backend = {
              -- The backend to use for searching. Defaults to "ripgrep".
              -- Available options:
              -- - "ripgrep", always use ripgrep
              -- - "gitgrep", always use git grep
              -- - "gitgrep-or-ripgrep", use git grep if possible, otherwise
              --   use ripgrep. Uses the same options as the gitgrep backend
              use = "ripgrep",

              -- Whether to set up custom highlight-groups for the icons used
              -- in the completion items. Defaults to `true`, which means this
              -- is enabled.
              customize_icon_highlight = true,

              ripgrep = {
                -- For many options, see `rg --help` for an exact description of
                -- the values that ripgrep expects.

                -- The number of lines to show around each match in the preview
                -- (documentation) window. For example, 5 means to show 5 lines
                -- before, then the match, and another 5 lines after the match.
                context_size = 5,

                -- The maximum file size of a file that ripgrep should include
                -- in its search. Useful when your project contains large files
                -- that might cause performance issues.
                -- Examples:
                -- "1024" (bytes by default), "200K", "1M", "1G", which will
                -- exclude files larger than that size.
                max_filesize = "1M",

                -- Enable fallback to neovim cwd if project_root_marker is not
                -- found. Default: `true`, which means to use the cwd.
                project_root_fallback = true,

                -- The casing to use for the search in a format that ripgrep
                -- accepts. Defaults to "--ignore-case". See `rg --help` for
                -- all the available options ripgrep supports, but you can try
                -- "--case-sensitive" or "--smart-case".
                search_casing = "--ignore-case",

                -- (advanced) Any additional options you want to give to
                -- ripgrep. See `rg -h` for a list of all available options.
                -- Might be helpful in adjusting performance in specific
                -- situations. If you have an idea for a default, please open
                -- an issue!
                --
                -- Not everything will work (obviously).
                additional_rg_options = {},

                -- Absolute root paths where the rg command will not be
                -- executed. Usually you want to exclude paths using gitignore
                -- files or ripgrep specific ignore files, but this can be used
                -- to only ignore the paths in blink-ripgrep.nvim, maintaining
                -- the ability to use ripgrep for those paths on the command
                -- line. If you need to find out where the searches are
                -- executed, enable `debug` and look at `:messages`.
                ignore_paths = {},

                -- Any additional paths to search in, in addition to the
                -- project root. This can be useful if you want to include
                -- dictionary files (/usr/share/dict/words), framework
                -- documentation, or any other reference material that is not
                -- available within the project root.
                additional_paths = {},
              },
            },

            gitgrep = {
              -- Any extra options you want to give to git grep. Can be used to
              -- e.g. exclude some files from the search.
              additional_gitgrep_options = {}
            },

            -- Show debug information in `:messages` that can help in
            -- diagnosing issues with the plugin.
            debug = false,
          },
          -- (optional) customize how the results are displayed. Many options
          -- are available - make sure your lua LSP is set up so you get
          -- autocompletion help
          transform_items = function(_, items)
            for _, item in ipairs(items) do
              -- example: append a description to easily distinguish rg results
              item.labelDetails = {
                description = "(rg)",
              }
            end
            return items
          end,
        },
      },
      keymap = {
        -- 👇🏻👇🏻 (optional) add a keymap to invoke the search manually
        ["<c-g>"] = {
          function()
            require("blink-cmp").show({ providers = { "ripgrep" } })
          end,
        },
      },
    },
  },
}
```

</details>

## 🏁 Performance

Generally performance is very good, but depending on the size of your project
and your computer's specifications, the search can be fast or slow. Here are a
few things you can do to improve performance:

- Use the git grep backend by setting the `backend = "gitgrep"` option (see
  above). This can be faster in medium/large projects, but note that it only
  provides results from files that are tracked by git.
- Set the `prefix_min_len` option to a larger number avoid starting a search for
  very short words. This can prevent unnecessary searches and improve
  performance.
- Use the `max_filesize` option to exclude large files from the search. This can
  prevent performance issues when searching in projects with large files.
- Disable automatic mode and use the manual mode to start the search only when
  you need it (see below).
- Set the `debug = true` option, which will log debug information to your
  `:messages` in Neovim. You can copy paste these commands to your terminal and
  try to figure out why the search is slow.
- Use the search backend's options to exclude/include files
  - ripgrep supports global as well as project/directory specific ignore files.
    By default, it uses `.gitignore`, `.git/info/exclude`, `.ignore`, and
    `.rgignore` files
    ([ripgrep docs](https://github.com/BurntSushi/ripgrep/blob/master/GUIDE.md#automatic-filtering))
  - git grep can be configured to ignore files using `.gitattributes` files. See
    [documentation/ignore-files-from-git-grep.md](documentation/ignore-files-from-git-grep.md)
    for more information.

- If you still experience performance issues, please open an issue for
  discussion.

### Automatic mode

In this mode, the search starts automatically when typing a word that is at
least `prefix_min_len` in length.

This is enabled by including the `ripgrep` provider in blink-cmp's providers:

```lua
return {
  -- ... other configuration
  ---@module 'blink.cmp'
  ---@type blink.cmp.Config
  opts = {
    sources = {
      default = {
        "lsp",
        "path",
        "snippets",
        "buffer",
        "ripgrep", -- 👈🏻 including this enables automatic search
      },
    }
  }
}
```

### Manual mode

If you prefer to start the search manually, you can use a keymap to invoke the
search. The example configuration includes a keymap that invokes the search when
pressing `Ctrl+g`.

## Highlight groups

The plugin uses the following highlight groups to style the results:

- `BlinkCmpKindRipgrepRipgrep` - the color of the icon used for ripgrep results
- `BlinkCmpKindRipgrepGit` - the color of the icon used for git grep results

## 🤔 How it works

When you enter insert mode and start typing a word, blink triggers a search with
blink-ripgrep. Only one search is done to save resources. After getting the
results, the following keys are used to filter the results.

In this demo (using the option `debug = true` above), we can see the search
starting when the word flashes with a different color. Notice how the word only
flashes once:

<!-- TODO add a better demo -->

<https://github.com/user-attachments/assets/0651ad24-0403-4ab9-81ff-59b152283593>

This is described in much more detail in blink's
[architecture documentation](https://cmp.saghen.dev/development/architecture.html).

<!-- vim: set ft=markdown: -->